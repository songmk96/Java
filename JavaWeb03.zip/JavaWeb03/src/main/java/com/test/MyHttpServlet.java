package com.test;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyHttpServlet extends HttpServlet {
	private String message;
	public void init() throws ServletException {
		this.message = "Hello My HttpServlet";
		System.out.println("init");
	}	
	public void doGet(HttpServletRequest req,
			HttpServletResponse res) 
					throws ServletException, IOException {
		
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.println("<h1>" + this.message + "</h1>");	
		System.out.println("doGet");
	}
	public void destory() {
		System.out.println("destory");
	}
	
}
