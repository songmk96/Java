package com.test;

/* 학생 디자인
	상태 : 이름, 나이, 성별
	동작 : 공부한다, 운동한다, 수업듣는다, 자습한다 ...
 */
class Student {
	public String name;
	public int age;
	public String gender;

	public void study() {
		System.out.println(name + "가 공부한다.");
	}
}

public class Sample04 {

	public static void main(String[] args) {

		Student stu = new Student();
		stu.name = "송민기";
		stu.age = 27;
		stu.gender = "남";
		stu.study();

		Student stu2 = new Student();
		stu2.name = "김정환";
		stu2.age = 27;
		stu2.gender = "남";
		stu2.study();
	}

}
