package com.test;

class Student2 {
	public String name; // member valuable(멤버 변수)
}

public class Sample06 {
	public static void main(String[] args) {
		Student2 stu = new Student2();
		System.out.println(stu.name);
		stu.name = "이순신";
		Student2 stu2 = stu;
		System.out.println(stu2.name);
	}

}
