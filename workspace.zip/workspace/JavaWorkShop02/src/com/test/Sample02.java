package com.test;

public class Sample02 {

	static void myFunc(int x) {
		x = x + 1;
	}

	// call by value, pass by value
	public static void main(String[] args) {
		int x = 10;
		myFunc(x);
		System.out.println(x);
	}
}

/*

*/
