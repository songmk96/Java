package com.test;

class Employee {
	public String name;

	public void working() {
		System.out.println(name);
	}
}

public class Sample05 {

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.name = "송민기";
		emp.working();

		Employee emp2 = emp; // 가리키는 방향(참조 방향)을 같게 만들어줌.
		emp2.working();

		Employee emp3 = new Employee();
		emp3.name = "이순신";
		emp3.working();

		chageName(emp3);
		emp3.working();
	}

	static void chageName(Employee e) {
		e.name = "세종대왕";
	}
}
