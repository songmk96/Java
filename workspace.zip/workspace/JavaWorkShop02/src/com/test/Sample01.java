package com.test;

class MyClass {
	static void display2(String name) {
		System.out.println(name);
	}
}

public class Sample01 {
	static int sum(int a, int b) { // 접근자를 적지않으면 default, static을 써주면 생성자없이 바로 쓸 수 있음, 메소드는 클래스 안에만 작성 가능(OPP이기 때문에
									// 클래스 단위로 관리)
		int c = a + b;
		return c;
	}

	static void display(String msg) {
		System.out.println(msg);
	}

	public static void main(String[] args) {
		int ret = sum(10, 20);
		System.out.println(ret);
		display("송민기");
		MyClass.display2("체블");
	}

}
