package com.test2;

//Account 객체
class Account {

	// 변수
	private String acc;
	private String name;
	private double price;
	static double interest;

	// 생성자
	public Account(String acc, String name, float price) {
		this.acc = acc;
		this.name = name;
		this.price = price;
	}

	// 메소드
	public String getAccountNo() {
		return this.acc;
	}

	public String getAccountName() {
		return this.name;
	}

	public double getBalance() {
		return this.price;
	}

	public void deposit(double d) {
		this.price += d;
	}

	public void withdraw(double w) {
		this.price -= w;
	}

	public void addInterest() {
		this.price = this.price + this.price * interest;
	}

}

public class AccountTest {

	static void printAccount(Account customer) {
		System.out.println("계좌번호:" + customer.getAccountNo());
		System.out.println("예금주이름:" + customer.getAccountName());
		System.out.println("잔액:" + customer.getBalance());
		System.out.println();
	}

	public static void main(String[] args) {
		Account customer1 = new Account("111-222-33333333", "최은희", 20000);
		Account customer2 = new Account("555-666-77777777", "남매월", 100000);
		System.out.println("기본 적립금");
		printAccount(customer1);
		printAccount(customer2);
		System.out.println("한번의 입출금");
		customer1.deposit(1000000);
		customer2.withdraw(30000);
		printAccount(customer1);
		printAccount(customer2);
		System.out.println("이자율의 계산");
		Account.interest = 0.05;
		customer1.addInterest(); // 저축된 금액=원금+원금*이자율
		customer2.addInterest();// 저축된 금액=원금+원금*이자율
		printAccount(customer1);
		printAccount(customer2);
	}

}
