package com.test2;

class A2 {
	int aVar;

	A2() {
	}

	A2(int aVar) {
		this.aVar = aVar;
		System.out.println("A Default Constructor aVar : " + this.aVar);
	}

	void aMethod() {
		System.out.println("aMethod");
	}
}

class B2 extends A2 {
	B2() {
		super(100);
	}

	void bMethod() {

		System.out.println("bMethod");
	}
}

public class Sample09 {

	public static void main(String[] args) {
		A2 a = new A2();
		B2 b = new B2();

	}

}
