package com.test2;

class Student {

	// 변수 자체를 직접 접근해서 바꾸는 것을 제한해줌. 메소드를 통해서만 접근 가능. => 캡슐화, encapsulation, 정보은닉
	private String name;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}

public class Sample01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
