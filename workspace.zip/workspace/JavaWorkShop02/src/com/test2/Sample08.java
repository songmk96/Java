package com.test2;

class Datebase {
	void open() {
		System.out.println("Database open");
	}
}

class Oracle extends Datebase {
	@Override
	void open() {
		System.out.println("Oracle open");
	}

	void select() {
		System.out.println("Oracle select");
	}
}

public class Sample08 {

	public static void main(String[] args) {
		Oracle oracle = new Oracle();
		oracle.open();
		oracle.select();
	}

}
