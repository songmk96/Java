package com.test2;

class MyClass4 {
	void blabla() {

	}

	private String name;
} // 클래스 내에서 멤버 변수를 먼저적던 나중에 적던 먼저 초기화되기 때문에 상관없다.

public class Sample06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
