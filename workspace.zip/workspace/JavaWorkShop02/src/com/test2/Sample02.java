package com.test2;

class Employee {
	// name 캡슐화
	private String name;

	// 생성자 오버로딩
	public Employee() {
		name = "이순신";
	}

	public Employee(String name) {
		this.name = name;
	}

	// name에 접근하기 위한 메소드
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}

public class Sample02 {

	public static void main(String[] args) {
		Employee emp = new Employee();
		System.out.println(emp.getName());
		Employee emp2 = new Employee("송민기");
		System.out.println(emp2.getName());
	}

}
