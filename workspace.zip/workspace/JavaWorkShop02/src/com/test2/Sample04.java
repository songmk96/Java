package com.test2;

class MyClass {
	static int a;
}

public class Sample04 {

	public static void main(String[] args) {
		System.out.println(MyClass.a);

		MyClass obj = new MyClass();
		MyClass.a = 100;
		System.out.println(obj.a);

		MyClass obj2 = new MyClass();
		System.out.println(obj2.a);

	}

}

//"인스턴스 변수"는 각각의 객체에서만 변수를 사용
//"정적 변수"는 따로 생성이 필요없고 같은 클래스로 정의된 객체에서 공용 사용