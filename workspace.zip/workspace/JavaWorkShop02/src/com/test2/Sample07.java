package com.test2;

class Animal {
	String name;

	void breath() {
		System.out.println("Animal breath : " + name);
	}
}

class Dog extends Animal {
	void bark() {
		System.out.println("Dog bark");
	}
}

class Cat extends Animal {
	void meow() {
		System.out.println("Cat meow");
	}
}

class Poodle extends Dog {

}

public class Sample07 {

	public static void main(String[] args) {

		Dog dog = new Dog();
		dog.breath();
		dog.bark();
		dog.name = "진돗개";

		Animal animal = new Animal();
		animal.breath();
		animal.name = "동물";

		Poodle poodle = new Poodle();
		poodle.breath();
		poodle.bark();
	}

}
