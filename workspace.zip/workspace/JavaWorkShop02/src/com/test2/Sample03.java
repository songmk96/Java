package com.test2;

class A {
	private int b;

	A() {
		System.out.println("Default Constructor");
	}

	A(int b) {
		this(); // 생성자 호출
		this.b = b;
		System.out.println("Constructor b :" + b);
	}
}

class Employee2 {
	private String name;

	public Employee2(String name) {
		this.name = name;
	}

	void working() {
		System.out.println(this.name);
	}
}

public class Sample03 {

	public static void main(String[] args) {
		A a = new A();
		A a2 = new A(10);
		Employee2 emp2 = new Employee2("송민기");
		emp2.working();

	}

}
