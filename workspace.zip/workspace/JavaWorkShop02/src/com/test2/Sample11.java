package com.test2;

class Student4 {
	String name;

	Student4(String name) {
		this.name = name;
	}
}

class MiddleStudent extends Student4 {
	MiddleStudent(String name) {
		super(name);
	}
}

public class Sample11 {

	public static void main(String[] args) {
		Student4 stu = new Student4("송민기");
		System.out.println(stu.name);

	}

}
