package com.test2;

class MyClass2 {
	static void aMethod() {
		System.out.println("aMethod");
	}

	void bMethod() {
		System.out.println("bMethod");
	}
}

class MyClass3 {
	static int a;

	// static 초기화
	static {
		a = 100;
	}
}

public class Sample05 {

	public static void main(String[] args) {

		MyClass2 obj = new MyClass2();
		obj.bMethod();
		obj.aMethod();

		MyClass2.aMethod();

		System.out.println(MyClass3.a);
	}

}
