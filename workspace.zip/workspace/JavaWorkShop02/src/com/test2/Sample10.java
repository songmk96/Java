package com.test2;

class A3 {
	int a;

	// 생성자
	A3() {
		System.out.println("A Default Constructor");
	}

	void setA(int a) {
		this.a = a;
	}
}

class B3 extends A3 {
	// 생성자
	B3() {
		super.setA(100);
		System.out.println("B Default Constructor a : " + a);
	}
}

public class Sample10 {

	public static void main(String[] args) {
		B3 b = new B3();
	}

}
