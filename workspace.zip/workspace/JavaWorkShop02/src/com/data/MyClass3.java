package com.data;

import java.util.Scanner;

//import com.data2.MyClass2;
import com.data2.MyClass2;

public class MyClass3 {

	public static void main(String[] args) {
		// 같은 클래스이기 때문에 com.data를 생략해도 됨.
		MyClass obj = new MyClass();
		com.data.MyClass obj2 = new com.data.MyClass();

		// import를 해주면 com.data 통해 직접 접근 안해도 됨.
		com.data2.MyClass2 obj3 = new com.data2.MyClass2();
		MyClass2 obj4 = new MyClass2();

		Scanner sc = new Scanner(System.in);
	}

}
