package com.test3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.Stack;

public class Sample05 {

	public static void main(String[] args) {
		// 스택
		Stack<String> s = new Stack<String>();
		s.push("10");
		s.push("20");
		s.push("30");

		s.pop();

		Iterator<String> itr = s.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		// 큐
		PriorityQueue<String> queue = new PriorityQueue<String>();
		queue.add("송민기");
		queue.add("홍찬민");
		queue.add("안정민");
		queue.add("정상현");
		queue.add("김광민");

		queue.poll();

		Iterator<String> itr2 = queue.iterator();
		while (itr2.hasNext()) {
			System.out.println(itr2.next());
		}
		// 셋 : 중복 제
		HashSet<Integer> set = new HashSet<Integer>();
		set.add(1);
		set.add(1);
		set.add(2);
		set.add(2);
		set.add(3);

		Iterator<Integer> itr3 = set.iterator();
		while (itr3.hasNext()) {
			System.out.println(itr3.next());
		}

		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "홍길동");
		map.put(1, "홍길동");
		map.put(2, "이순신");
		map.put(3, "세종대왕");
		Set s2 = map.entrySet();
		Iterator itr4 = set.iterator();
		while (itr4.hasNext()) {
			Map.Entry<Integer, String> entry = (Map.Entry<Integer, String>) itr4.next();
			System.out.println(entry.getKey() + ", " + entry.getValue());
		}
	}

}
