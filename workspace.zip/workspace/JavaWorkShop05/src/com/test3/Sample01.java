package com.test3;

interface Drawable {
	public void draw();
}

interface Drawable2 {
	public int draw(int a, int b);
}

public class Sample01 {
	static void Test(Drawable d) {
		d.draw();
	}

	public static void main(String[] args) {
		Test((s) -> System.out.println());

		Drawable d = new Drawable() {
			public void draw() {
				System.out.println("draw");
			}
		};
		d.draw();
		Drawable d2 = () -> {
			System.out.println("draw2");
		};
		d2.draw();
		Drawable2 d3 = (int x, int y) -> { // 변수명 상관 없이 데이터 타입만 맞춰주면 됨.
			return 0;
		};
		d3.draw(20, 30);
		Drawable2 d4 = (s, t) -> { // 데이터 타입도 생략 가능.
			return 0;
		};
	}

}
