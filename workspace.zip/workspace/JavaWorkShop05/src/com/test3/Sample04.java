package com.test3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Sample04 {
	static void Test(List<String> a) {

	}

	public static void main(String[] args) {
		Test(new ArrayList<String>());
		Test(new ArrayList<String>());

		List<String> al = new ArrayList<String>();
		al.add("홍길동");
		al.add("아순신");

		for (String s : al) {
			System.out.println(s);
		}

		Iterator itr = al.listIterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
