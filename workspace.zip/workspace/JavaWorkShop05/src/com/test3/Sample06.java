package com.test3;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Sample06 {

	public static void main(String[] args) {
		String[] names = { "홍길동", "이순신", "세종대왕" };
		List<String> n = Arrays.asList(names);
		Collections.sort(n);
		System.out.println(n);
	}

}
