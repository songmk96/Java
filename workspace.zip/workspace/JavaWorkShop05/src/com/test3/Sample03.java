package com.test3;

import java.util.function.Consumer;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Sample03 {

	public static void main(String[] args) {
		IntPredicate e = x -> x % 2 == 0;
		boolean b = e.test(10);
		System.out.println(b);
		Predicate<Integer> e2 = a -> a / a == 1;
		System.out.println(e2.test(20));

		Consumer<String> e3 = s -> System.out.println(s);
		e3.accept("홍길동");
	}

}
