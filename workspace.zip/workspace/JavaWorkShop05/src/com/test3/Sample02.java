package com.test3;

interface Calc {
	int add(int a, int b);
}

public class Sample02 {
	static void calculate(Calc c) {
		int d = c.add(10, 20);
		System.out.println(d);
	}

	public static void main(String[] args) {
		calculate((x, y) -> {
			return x + y;
		});
	}

}
