package com.test2;

// 람다식의 장점 : 따로 클래스를 만들지 않고 메소드를 만들어서 사용 가능
// 객체지향 언어의 코드가 너무 길다는 단점을 코드길이가 단축되는 트렌드를 따르기 위해 함수형 언어의 특징을 차용한 것.
interface Negative {
	int neg(int x);
}

interface Test {
	void aTest();
}

public class Sample02 {

	public static void main(String[] args) {
		// Negative
		Negative n = (int a) -> {
			return a;
		};

		int ret = n.neg(10);
		System.out.println(ret);

		// Test
		Test t = () -> {
			System.out.println("Test");
		};

		t.aTest();
	}

}
