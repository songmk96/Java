package com.test2;

// 제너릭 메서드
public class Sample01 {
	static <E> void printArray(E[] elements) {
		for (E e : elements) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
		// 박싱
		Integer[] arr = { 10, 20, 30, 40 };
		printArray(arr);
	}

}
