package com.test;

//abstract class Student {
//	abstract void gotoSchool();
//}

interface Student {
	void gotoSchool();
}

public class Sample01 {

	public static void main(String[] args) {
		Student stu = new Student() {
			public void gotoSchool() {
				System.out.println("Student gotoSchool");
			}
		};
		stu.gotoSchool();
	}

}
