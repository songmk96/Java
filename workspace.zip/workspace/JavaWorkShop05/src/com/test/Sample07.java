package com.test;

import java.util.ArrayList;

class Student2 {
	// 멤버 변수
	private String name;

	// 생성자
	Student2(String name) {
		this.name = name;
	}

	// getter&setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

public class Sample07 {

	public static void main(String[] args) {
		ArrayList<Student2> al = new ArrayList<>();
		al.add(new Student2("홍길동"));
		al.add(new Student2("이순신"));
		for (Student2 s : al) {
			System.out.println(s.getName());
		}
	}

}
