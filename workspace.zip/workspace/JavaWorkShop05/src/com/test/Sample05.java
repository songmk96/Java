package com.test;

class MyClass2 {
	private Object t;

	public MyClass2(Object t) {
		this.t = t;
	}

	public Object getT() {
		return this.t;
	}

	public void setT(Object t) {
		this.t = t;
	}
}

class MyClass3<T> {
	private T t;

	public MyClass3(T t) {
		this.t = t;
	}

	public T getT() {
		return this.t;
	}

	public void setT(T t) {
		this.t = t;
	}
}

public class Sample05 {

	public static void main(String[] args) {
		MyClass2 obj = new MyClass2("이순신");
		Object o = obj.getT();
		String s = (String) o;
		System.out.println(s);

		// 제너릭을 사용하면 캐스팅을 줄일 수 있다.
		MyClass3<String> obj2 = new MyClass3<>("송민기");
		String s2 = obj2.getT();
		System.out.println(s2);
	}

}
