package com.test;

// custom 예외 처리
class InvalidAgeException extends Exception {
	public InvalidAgeException(String msg) {
		super(msg);
	}
}

public class Sample03 {

	static void validate(int age) throws InvalidAgeException {
		if (age < 18) {
			throw new InvalidAgeException("18세 보다 작습니다.");
		}
	}

	public static void main(String[] args) {
		try {
			validate(16);
		} catch (InvalidAgeException e) {
			System.out.println("예외 발생");
			System.out.println(e.getMessage());
		}
	}

}
