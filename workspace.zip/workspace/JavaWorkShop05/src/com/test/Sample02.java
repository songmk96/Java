package com.test;

import java.io.IOException;

public class Sample02 {

	static void m() throws IOException {
//		System.out.println("IOException Message");
		throw new IOException();
	}

	public static void main(String[] args) {
		try {
			m();
		} catch (IOException e) {
			System.out.println("IOException Error");
		}
	}

}
