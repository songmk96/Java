package com.test;

class MyClass<T> {
	T a;

	MyClass(T a) {
		this.a = a;
	}

	public void setA(T a) {
		this.a = a;
	}

	public T getA() {
		return this.a;
	}
}

public class Sample04 {

	public static void main(String[] args) {
		MyClass<Integer> a = new MyClass<Integer>(10);
		MyClass<String> a2 = new MyClass<String>("이순신");
		a2.setA("송민기");
		System.out.println(a2.getA());

	}

}
