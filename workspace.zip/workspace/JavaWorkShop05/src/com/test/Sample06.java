package com.test;

import java.util.ArrayList;

class MyTest<T, U> {
	T obj1;
	U obj2;

	MyTest(T obj1, U obj2) {
		this.obj1 = obj1;
		this.obj2 = obj2;
	}

	public void display() {
		System.out.println(obj1);
		System.out.println(obj2);
	}
}

public class Sample06 {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("10");
		al.add("20");
		ArrayList<Integer> al2 = new ArrayList<>();
		al2.add(10);
		al2.add(20);
		MyTest<String, Integer> obj4 = new MyTest<>("송민기", 27);
		obj4.display();
	}

}
