package com.test;

public class School2 {
	public String name;
	private String name2;
	protected String name3;
	String name4;

}
