package com.test;

class Student {
	private String name;

	// getter & setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// Constructor Overloading
	Student() {
		this.name = "송민기";
	}

	Student(String name) {
		this.name = name;
	}

	// Method Overloading
	public void study() {
		System.out.println("공부하다");
	}

	public void study(String name) {
		System.out.println(name + "가 공부하다");
	}

	// static
	static int grade;
	static {
		grade = 1;
	}

	static void getGrade() {
		System.out.println(grade);
	}
}

class MiddleStudent extends Student {
	MiddleStudent() {
		super("이순신");
	}

	@Override
	public void study() {
		System.out.println("중학생이 공부한다");
	}

	public void play() {
		System.out.println("운동한다");
	}
}

public class Sample01 {

	public static void main(String[] args) {
		Student stu;
		stu = new Student();
		Student stu2 = new Student();
		Student.grade = 2;
		Student.getGrade();
		stu2.grade = 3;
		stu2.getGrade();
		MiddleStudent middleStu = new MiddleStudent();
	}

}
