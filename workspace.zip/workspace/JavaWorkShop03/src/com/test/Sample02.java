package com.test;

import com.test2.School;

public class Sample02 {

	public static void main(String[] args) {
		School s = new School();
		s.name = "부개초등학교";
		s.name2 = "일신초등학교";
		s.name3 = "부개서초등학교";
		s.name4 = "금마초등학교";
		// 다른 패키지는 public만 접근 가능

		School2 s2 = new School2();
		s2.name = "부개초등학교";
		s2.name2 = "일신초등학교";
		s2.name3 = "부개서초등학교";
		s2.name4 = "금마초등학교";
		// 같은 패키지는 private만 접근 불가능
	}

}
