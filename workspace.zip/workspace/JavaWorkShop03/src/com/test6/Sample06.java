package com.test6;

abstract class Database {
	void open() {

	}

	abstract void close();
}

class Oracle extends Database {
	void close() {
		System.out.println("Oracle close");
	}
}

public class Sample06 {

	public static void main(String[] args) {
		Oracle oracle = new Oracle();
		oracle.open();
		oracle.close();

		// 추상클래스도 타입은 받을 수 있다.
		Database db = new Oracle();
		db.close();
	}

}
