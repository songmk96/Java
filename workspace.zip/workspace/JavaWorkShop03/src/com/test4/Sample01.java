package com.test4;

// 캐스팅이 안되는 경우
class Animal {

}

class Dog extends Animal {

}

class Cat extends Animal {

}

public class Sample01 extends Object {
	public static void main(String[] args) {
		// Animal 객체에서 Dog로 캐스팅하게되면 오류남 => 아래로 갈 수 없음
		Animal animal = new Animal();
		Dog dog = (Dog) animal;

		// dog 객체를 animal로 캐스팅 한 후 cat으로 캐스팅 하게되면 오류남 => 형제 객체로 갈 수 없음
		Dog dog2 = new Dog();
		Animal animal2 = dog2;
		Cat cat = (Cat) animal2;

		// object는 모든 객체를 받을 수 있다.
		Animal a = new Animal();
		Object a2 = a;
	}
}

/* 공식 문서 : https://docs.oracle.com/en/java/javase/11/docs/api/index.html */
