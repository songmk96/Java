package com.test4;

class A {
	int aM;
}

public class Sample02 {

	public static void main(String[] args) {
		A a = new A();
		String className = a.getClass().getName();
		System.out.println(className);
		String className2 = a.getClass().getSimpleName();
		System.out.println(className2);

		// instanceof
		if (a instanceof A) {
			System.out.println(a.aM);
		}

		Dog dog = new Dog();
		if (dog instanceof Animal) {
			System.out.println("O.K");
		}

		Dog dog2 = null;
		if (dog2 instanceof Dog) {
			System.out.println("O.K");
		} else {
			System.out.println("Not O.K");
		}
	}

}
