package com.test3;

class Student {
	void gotoSchool() {
		System.out.println("학생이 학교애 간다.");
	}
}

class MiddleStudent extends Student {
	void eatLunch() {
		System.out.println("중학생이 점심식사를 한다.");
	}
}

class HighStudent extends Student {
	void playGame() {
		System.out.println("고등학생이 게임을 한다.");
	}
}

public class Sample2 {

	public static void main(String[] args) {
		Student stu = new Student();
		stu.gotoSchool();
		MiddleStudent midStu = new MiddleStudent();
		midStu.eatLunch();
		midStu.gotoSchool();
		Student stu2 = new MiddleStudent(); // 객체는 MiddleStudent인데 타입은 Student => 따라서 Student 메소드만 쓸 수 있다.
		stu2.gotoSchool();
		MiddleStudent midStu2 = (MiddleStudent) stu2; // Student 타입을 MiddleStudent 타입으로 내려준다.
		midStu2.eatLunch();
		midStu2.gotoSchool();
		Student highStu = new HighStudent();
		highStu.gotoSchool();

		displayMiddleStudent(new MiddleStudent()); // MiddleStudent m = new MiddleStudent();
		displayHighStudent(new HighStudent()); // HighStudent h = new HighStudent();

		// 객체 타입 변환을 하는 이유
		displayStudent(new MiddleStudent());
		displayStudent(new HighStudent());
	}

	static void displayMiddleStudent(MiddleStudent m) {
		m.gotoSchool();
		m.eatLunch();
	}

	static void displayHighStudent(HighStudent h) {
		h.gotoSchool();
		h.playGame();
	}

	static void displayStudent(Student s) {
		String className = s.getClass().getName();

		switch (className) {
		case "MiddleStudent":
			MiddleStudent mid = (MiddleStudent) s;
			mid.eatLunch();
			mid.gotoSchool();
			break;
		case "HighStudent":
			HighStudent hi = (HighStudent) s;
			hi.gotoSchool();
			hi.playGame();
			break;
		}
	}
}
