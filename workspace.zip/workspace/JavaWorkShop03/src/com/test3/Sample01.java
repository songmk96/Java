package com.test3;

class Animal {
	void breath() {
		System.out.println("Animal breath");
	}
}

class Dog extends Animal {

	void bark() {
		System.out.println("Dog bark");
	}
}

class Cat extends Animal {

	void meow() {
		System.out.println("Cat meow");
	}
}

public class Sample01 {

	public static void main(String[] args) {
		// value type casting
		int a = Integer.MAX_VALUE;
		long b = a;
		long c = Long.MAX_VALUE;
		int d = (int) c;

		// reference type casting
		Animal animal = new Animal();
		animal.breath();

		Dog dog = new Dog();
		dog.breath();
		dog.bark();

		Animal animal2 = dog; // 암시적인 형변환 : 객체는 Dog 객체인데 타입은 Animal
		Dog dog2 = (Dog) animal2;// 명시적인 형변환 : 다시 Dog 타입으로 변환
	}

}
