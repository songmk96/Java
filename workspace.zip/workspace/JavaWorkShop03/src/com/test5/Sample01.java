package com.test5;

class Animal {
	void breath() {
		System.out.println("Animal breath");
	}
}

class Dog extends Animal {
	@Override
	void breath() {
		System.out.println("Dog breath");
	}
}

class Cat extends Animal {
	@Override
	void breath() {
		System.out.println("Cat breath");
	}
}

public class Sample01 {
	public static void main(String[] args) {
		Animal animal = new Animal();
		display(animal);
		Dog dog = new Dog();
		display(dog);
		Cat cat = new Cat();
		display(cat);

		Animal[] animals = new Animal[3];
		animals[0] = new Animal();
		animals[1] = new Dog();
		animals[2] = new Cat();
		for (Animal a : animals) {
			a.breath();
		}
	}

	static void display(Animal a) {
		a.breath();
	}
}
