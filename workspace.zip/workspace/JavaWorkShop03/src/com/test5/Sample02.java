package com.test5;

class Database {
	void open() {
		System.out.println("Database open");
	}
}

class Oracle extends Database {
	void open() {
		System.out.println("Oracle open");
	}
}

class MySql extends Database {
	void open() {
		System.out.println("MySql open");
	}
}

public class Sample02 {

	public static void main(String[] args) {
		// 일일히 객체 생성
		Database db = new Database();
		db.open();
		Database db2 = new Oracle();
		db2.open();
		Database db3 = new MySql();
		db3.open();

		// 메소드를 이용하여 객체 생성
		Database db4 = createDatabase("Oracle");
		db4.open();
		Database db5 = createDatabase("MySql");
		db5.open();

		// 나중에 데이터베이스 종류가 추가될때(NoSql, MongoDB) 수정하기 편함.
		// 일일히 객체를 생성했으면 일일히 텍스트를 수정해줘야하지만,
		// 메소드를 사용하면 상속받는 class와 메소드를 수정해주면 된다.
	}

	static Database createDatabase(String dbName) {
		Database db = null;
		switch (dbName) {
		case "Oracle":
			db = new Oracle();
			break;
		case "MySql":
			db = new MySql();
			break;
		}
		return db;
	}
}
