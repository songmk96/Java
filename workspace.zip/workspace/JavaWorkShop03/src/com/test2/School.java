package com.test2;

public class School {
	public String name;
	private String name2;
	protected String name3;
	String name4;

}
