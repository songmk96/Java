package com.test7;

interface Database {
	void open();

	void close();
}

class Oracle implements Database {
	@Override
	public void open() {
		System.out.println("Oracle open");
	}

	@Override
	public void close() {
		System.out.println("Oracle close");
	}
}

class MySql implements Database {
	@Override
	public void open() {
		System.out.println("MySql open");
	}

	@Override
	public void close() {
		System.out.println("MySql close");
	}
}

public class Sample01 {

	public static void main(String[] args) {

//		Database db = new Database();   => 생성은 안됨.

		Oracle oracle = new Oracle();
		oracle.open();
		oracle.close();

	}

}
