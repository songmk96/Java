package ws1.java2.driver;

import ws1.java2.controller.VehicleManager;

public class VehicleDriver {
	public static void main(String[] args) {
		VehicleManager vm = new VehicleManager();
		vm.displayVehicles(">> 재고 목록 <<");
	}
}
