package com.test4;

public class Sample06 {
	enum menu {
		pasta("파스타"), nuddle("국수");

		private String s;

		menu(String s) {
			this.s = s;
		}

		public String toString() {
			return s;
		}
	}

	enum Season {
		SPRING, SUMMER, FALL, WINTER;
	}

	public static void main(String[] args) {
		System.out.println(menu.pasta);
		for (Season m : Season.values()) {
			System.out.println(m.name());
		}

		for (Season s : Season.values()) {
			System.out.println(s + ", " + s.ordinal());
		}
	}

}
