package com.test4;

enum Gender {
	MALE, FEMALE
}

enum Direction {
	EAST, WEST, SOUTH, NORTH
}

public class EnumDemo01 {

	public static void main(String[] args) {
		Gender gender = Gender.FEMALE;

	}

}
