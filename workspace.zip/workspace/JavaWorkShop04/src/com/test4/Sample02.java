package com.test4;

import java.util.ArrayList;

public class Sample02 {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.remove(1);
		al.add(1, 10);
		for (Object v : al) {
			System.out.println(v);
		}
		System.out.println(al.get(2));
	}

}
