package com.test4;

public class Sample01 {
	int a;

	void aMethod(int a) {
		System.out.println(a);
	}

	static void bMethod(int b) {
		System.out.println(b);
	}

	public static void main(String[] args) {
		Sample01 s = new Sample01(); // static이 없는 메소드를 쓰기 위해 자기자신의 클래스 객체 생성
		s.aMethod(20);
		s.bMethod(30);

	}

}
