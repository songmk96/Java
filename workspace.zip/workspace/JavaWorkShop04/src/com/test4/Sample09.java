package com.test4;

public class Sample09 {

	public static void main(String[] args) {
		try {
			int a = 10;
			int b = 0;
			int c = a / b;
		} catch (ArithmeticException ex) {
			System.out.println(ex.getMessage());
			System.out.println("관리자에게 문의를 주세요.");
		}

		try {
			int[] arr = new int[2];
			arr[2] = 10;
		} catch (ArrayIndexOutOfBoundsException ex) {
			System.out.println(ex.getMessage() + " 인덱스 범위를 넘었습니다.");
		} catch (Exception ex) { // 마지막 보루
			System.out.println("Exception");
		} finally { // 오류가 발생하든 안하든 실행
			System.out.println("Finally");
		}
	}

}
