package com.test4;

public class Sample11 {

	static void testException() throws ArithmeticException {
		int a = 10 / 0;
	}

	static void testException2() { // throws를 이용하지 않으면 이렇게 일일히 try~catch구문을 작성해줘야 한다.
		try {
			throw new Exception();
		} catch (Exception ex) {

		}
	}

	public static void main(String[] args) {

		try {
			testException();
		} catch (ArithmeticException ex) {
			System.out.println("ArithmeticException");
		}
	}

}

//모든 메소드를 일일히 try~catch구문을 쓰는것보다 throws로 오류처리를 넘겨주어 한 곳에서만 처리하는게 코드의 중복을 줄일 수 있다.