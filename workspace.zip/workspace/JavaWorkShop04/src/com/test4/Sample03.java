package com.test4;

import java.util.ArrayList;

class Dept {
	private int deptId;
	private String deptName;

	// 생성자
	Dept(int deptId, String deptName) {
		this.deptId = deptId;
		this.deptName = deptName;
	}

	// getter&setter
	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
}

public class Sample03 {

	public static void main(String[] args) {
//		int[] deptIds = {10, 20, 30};
//		String[] deptNames = {"총무팀", "회계팀", "전산팀"};

//		Dept[] depts = new Dept[3];
//		depts[0] = new Dept(10, "총무팀");
//		depts[1] = new Dept(20, "회계팀");
//		depts[2] = new Dept(30, "전산팀");
//		for (Dept d : depts) {
//			System.out.println(d.getDeptId() + ", " + d.getDeptName());

		ArrayList depts = new ArrayList();
		depts.add(new Dept(10, "총무팀"));
		depts.add(new Dept(20, "회계팀"));
		depts.add(new Dept(30, "전산팀"));
		for (Object o : depts) {
			Dept d = (Dept) o;
			System.out.println(d.getDeptId() + ", " + d.getDeptName());
		}
	}

}
