package com.test4;

public class Sample08 {

	public static void main(String[] args) {
		// Boxing
		Integer a = new Integer(10);
		// Auto Boxing
		Integer a2 = 10;
		// Unboxing
		int a3 = a2.intValue();
		// Auto Unboxing
		int a4 = a2;
	}

}
