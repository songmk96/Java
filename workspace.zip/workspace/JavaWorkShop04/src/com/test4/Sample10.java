package com.test4;

class MyClass2 {
	void m() {
		int data = 10 / 0;
	}

	void n() {
		m();
	}

	void p() {
		try {
			n();
		} catch (Exception e) {
			System.out.println("Exception");
		}
	}
}

public class Sample10 {

	public static void main(String[] args) {
		MyClass2 obj = new MyClass2();
		obj.p();
	}

}
