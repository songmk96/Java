package com.test4;

public class Sample04 {

	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
		}
	}

}

// javac Sample04.java => Smaple04.class