package com.test4;

public class Sample05 {
	static void test(int[] arr) { // int[] arr = err;
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

	// 가변 개수 매개변수
	static void test2(int... arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

	public static void main(String[] args) {
		int[] err = { 10, 20, 30, 40 };
		test(err);
		test2(10, 20);
	}

}
//차이점 : test는 arr의 레퍼런스를 넘겨줘야하지만 test2는 데이터 자체를 넘겨준다.
