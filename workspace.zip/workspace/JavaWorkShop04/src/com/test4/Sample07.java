package com.test4;

class MyClass extends Object {
	private String name;

	MyClass(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return name + " 입니다.";
	}

	public boolean equals(Object o) {
		MyClass m = (MyClass) o;
		if (this.name == m.name) {
			return true;
		} else {
			return false;
		}
	}

}

public class Sample07 {

	public static void main(String[] args) {
		MyClass m = new MyClass("송민기");
		System.out.println(m.hashCode());
		MyClass m2 = new MyClass("송민기");
		System.out.println(m2.hashCode());
		if (m.equals(m2)) {
			System.out.println("O.K");
		}
	}

}
