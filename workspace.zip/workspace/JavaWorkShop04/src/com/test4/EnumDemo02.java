package com.test4;

public class EnumDemo02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
