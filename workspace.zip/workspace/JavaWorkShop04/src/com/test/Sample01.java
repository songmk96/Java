package com.test;

class Database {
	void open() {
		System.out.println("Database open");
	}
}

class Oracle extends Database {
	void select_oracle() {
		System.out.println("Oracle select");
	}
}

class MySql extends Database {
	void select_mysql() {
		System.out.println("MySql select");
	}
}

public class Sample01 {

	static void dbOpen(Object db) {
		Database temp = (Database) db;
	}

	static Database dbOpne(Database db) {
		db.open();
		return db;
	}

	public static void main(String[] args) {
		Database db = new Database();
		db.open();

		// Oracle oracle = new Oracle();
		// Database db2 = oracle;
		Database db2 = new Oracle();
		db2.open();

		Oracle oracle = (Oracle) db2;
		oracle.open();
		oracle.select_oracle();

		MySql mysql = new MySql();
		mysql.open();
		mysql.select_mysql();
	}

}
