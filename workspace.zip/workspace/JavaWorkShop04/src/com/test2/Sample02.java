package com.test2;

class A {
	void aMethod() {
		System.out.println("aMethod");
	}
}

class B extends A {
	void aMethod() {
		System.out.println("aMethod Override");
	}
}

class C extends B {
	void aMethod() {
		System.out.println("aMethod Override Override");
	}
}

public class Sample02 {

	public static void main(String[] args) {
		A a = new A();
		a.aMethod();

		A a1 = new C();
		a1.aMethod();

		B c = new C();
		c.aMethod();
	}

}
