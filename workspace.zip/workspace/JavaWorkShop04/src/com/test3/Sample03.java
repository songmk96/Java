package com.test3;

public class Sample03 {

	public static void main(String[] args) {
		Student stu = 
				new Student() {
			public void goto
		}
	}

}
