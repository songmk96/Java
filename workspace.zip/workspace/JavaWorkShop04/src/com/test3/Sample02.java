package com.test3;

interface Calculator {
	int calculate(int a, int b);
}

class Plus implements Calculator {
	public int calculate(int a, int b) {
		return a + b;
	}
}

class Minus implements Calculator {
	public int calculate(int a, int b) {
		return a - b;
	}
}

class Divide implements Calculator {
	public int calculate(int a, int b) {
		return a / b;
	}
}

//관리클래스
class Calc {
	Calculator c;

	Calc(Calculator c) { // Calculator c = new Plus();
		this.c = c;
	}

	public int calculate(int x, int y) {
		return c.calculate(x, y);
	}
}

public class Sample02 {

	public static void main(String[] args) {
		Calc c = new Calc(new Plus());
		int ret = c.calculate(20, 10);
		System.out.println(ret);
	}

}
