package com.test3;

interface Database {
	void open();
}

class Oracle implements Database {
	public void open() {
		System.out.println("Oracle open");
	}
}

class MySql implements Database {
	public void open() {
		System.out.println("MySql open");
	}
}

public class Sample01 {

	static Database createDatabase(String dbName) {
		Database db = null;
		switch (dbName) {
		case "Oracle":
			db = new Oracle();
			break;
		case "MySql":
			db = new MySql();
			break;
		}
		return db;
	}

	public static void main(String[] args) {
		Database db = new Oracle();
		db.open();

		Database db1 = createDatabase("MySql");
		db1.open();
	}

}

//public void 왜? 기본적으로 interface는 public이 생략되어 있어서
//Database를 참조했는데 "Oracle open" 이 출력되는 이유? 인터페이스 특성