package com.test3;

import java.util.ArrayList;

public class Sample05 {

	public static void main(String[] args) {
		// 선언 및 할당 1
		int[] arr = new int[3];
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		// 선언 및 할당 2
		int[] arr2 = new int[] { 10, 20, 30 };
		// 선언 및 할당 3
		int[] arr3 = { 10, 20, 30 };
		// for문으로 출력
		for (int i = 0; i < arr3.length; i++) {
			System.out.println(arr3[i]);
		}
		// for~each문
		for (int s : arr3) {
			System.out.println(s);
		}
		// 동적배열
		ArrayList al = new ArrayList();
		al.add(1);
		al.add("홍길동");
		al.add(new Object());

		for (int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i));
			System.out.println(al.get(i).toString());
		}

		for (Object o : al) {
			System.out.println(o);
		}
		ArrayList<Integer> al2 = new ArrayList<Integer>();
		al2.add(100);
	}

}
