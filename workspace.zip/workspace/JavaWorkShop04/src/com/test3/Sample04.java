package com.test3;

public class Sample04 {

	public static void main(String[] args) {
		String s1 = "송민기";
		String s2 = "송민기";
		if (s1 == s2) {
			System.out.println("s1 == s2");
		} else {
			System.out.println("s1 != s2");
		}
		String s3 = new String("송민기");
		if (s1 == s3) {
			System.out.println("s1 == s3");
		} else {
			System.out.println("s1 != s3");
		}
		if (s1.equals(s3)) {
			System.out.println("s1 == s3");
		} else {
			System.out.println("s1 != s3");
		}
	}

}
