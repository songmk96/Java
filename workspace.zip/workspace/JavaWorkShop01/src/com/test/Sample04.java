package com.test;

public class Sample04 {

	public static void main(String[] args) {
		int a = Integer.MAX_VALUE;
		long b = a; // 암시적인 형변환, implicit casting
		System.out.println(b);
		short c = (short) a;
		System.out.println(c); // 명시적인 형변환, explicit casting

		System.out.printf("%d는 암시적인 형변환", a);
		System.out.println();
		String name = "송민기";
		System.out.printf("나의 이름은 %s", name);
	}

}
