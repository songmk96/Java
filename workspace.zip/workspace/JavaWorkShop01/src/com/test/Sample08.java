package com.test;

public class Sample08 {

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		int c = (a > b) ? 100 : 200;
		System.out.println(c);

	}

}
