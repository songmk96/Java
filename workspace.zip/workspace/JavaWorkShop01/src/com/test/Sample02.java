package com.test;

public class Sample02 {

	public static void main(String[] args) {
		byte a = 10;
		byte b = -20;
		byte c = Byte.MAX_VALUE;
		short s = 100;
		short s2 = Short.MAX_VALUE;
		int t = 1000;
		int t2 = Integer.MAX_VALUE;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(s);
		System.out.println(s2);
		System.out.println(t);
		System.out.println(t2);

		float u = Float.MAX_VALUE;
		float u2 = 1000.0f; // f는 float 타입임을 명시
		double v = Double.MAX_VALUE;
		double v2 = 1000.00d;
		boolean x = false;
		boolean x2 = true;
		char z = 'a';
		char z2 = 66;
		System.out.println(u);
		System.out.println(u2);
		System.out.println(v);
		System.out.println(v2);
		System.out.println(x);
		System.out.println(x2);
		System.out.println(z);
		System.out.println(z2);

	}

}
