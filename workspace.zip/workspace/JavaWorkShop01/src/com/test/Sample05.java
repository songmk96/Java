package com.test;

import java.util.Scanner;

public class Sample05 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("숫자를 입력해주세요 : ");
		int x = in.nextInt();
		System.out.println("x : " + x);
	}

}
