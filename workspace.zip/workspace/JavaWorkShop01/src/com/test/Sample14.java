package com.test;

public class Sample14 {
	static int add(int a, int b) {
		return a + b;
	}

	int divide(int a, int b) {
		return a / b;
	}

	public static void main(String[] args) {

		int ret = add(10, 20);
		System.out.println(ret);
		Sample14 s = new Sample14();

		// divide(10, 2);
		int ret2 = s.divide(10, 2);
		System.out.println(ret2);

	}

}
