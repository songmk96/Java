package com.test;

public class Sample06 {

	public static void main(String[] args) {
		int a = 0;
		int b = a++;
		System.out.println(b);
		System.out.println(a);

		int a2 = 0;
		int b2 = ++a2;
		System.out.println(b2);
		System.out.println(a2);

		int a3 = 0;
		int b3 = a3++ + ++a3;
		System.out.println(b3);
	}

}
