package com.test;

public class Sample13 {

	public static void main(String[] args) {
		for (int a = 2; a < 10; a++) {
			System.out.println(a);
		}
		for (int a = 2; a < 10; a++) {
			for (int b = 1; b < 10; b++) {
				System.out.println(a + " x " + b + " = " + (a * b));
			}
			System.out.println();
		}
	}
}
