package com.test;

import java.util.Scanner;

public class Workshop1_2 {

	public static float getUserInput() {
		Scanner scanner = new Scanner(System.in);
		String inputString = scanner.nextLine();
		return Float.parseFloat(inputString);

	}

	public static void main(String[] args) {

		// 성적
		System.out.print("Computer Science 성적을 입력하세요 : ");
		float cs = getUserInput();

		System.out.print("Java Programming 성적을 입력하세요 : ");
		float java = getUserInput();

		System.out.print("공학수학 성적을 입력하세요 : ");
		float math = getUserInput();

		System.out.print("오페라의 이해 성적을 입력하세요 : ");
		float opera = getUserInput();

		System.out.print("배드민턴 성적을 입력하세요 : ");
		float bm = getUserInput();

		// 출력
		System.out.println("==============================");
		float grade = (cs + java + math + opera + bm) / 5;
		System.out.printf("평점은 %.1f점 입니다.\n", grade);

		if (cs >= 2.5 && java >= 2.5 && math >= 2.5 && opera >= 2.5 && bm >= 2.5 && grade >= 3.7) {
			System.out.print("다음 학기 장학금 대상자 입니다.");
		}
	}

}
