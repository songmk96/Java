package com.test;

public class Sample12 {

	public static void main(String[] args) {
		int a = 0;
		while (a <= 10) {
			System.out.print(a + " ");

			a++; // a = a + 1;
		}

		System.out.println();
		int b = 1;
		int c = 2;
		while (b < 10) {
			while (c < 10) {
				System.out.printf("%d x %d = %d\n", b, c, b * c);
				c++;
			}
			b++;
		}

	}

}
