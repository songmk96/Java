package com.test;

public class Sample01 {
	static int d = 100;

	void method() {
		int f = 90;
	}

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		int c = a + b;
		System.out.println("c : " + c);
		int g = 100;
	}

}
