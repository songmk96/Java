package com.test;

import java.util.Scanner;

public class Workshop1_1 {

	public static int getUserInput() {
		Scanner scanner = new Scanner(System.in);
		String inputString = scanner.nextLine();
		return Integer.parseInt(inputString);

	}

	public static void main(String[] args) {

		// 메뉴
		System.out.println("========= 메뉴 =========");
		System.out.println("1. 아메리카노 2000원");
		System.out.println("2. 카페라떼 3000원");
		System.out.println("3. 베이글 1500원");
		System.out.println("4. 크림치즈 500원");

		// 주문
		System.out.println("========= 주문 =========");

		System.out.print("아메리카노 주문 수량:");
		int ame = getUserInput();

		System.out.print("카페라떼 주문 수량:");
		int latte = getUserInput();

		System.out.print("베이글 주문 수량:");
		int bagel = getUserInput();

		System.out.print("크림치즈 주문 수량:");
		int cream = getUserInput();

		// 금액
		System.out.println("========= 금액 =========");
		System.out.printf("아메리카노 : %d원\n", ame * 2000);
		System.out.printf("카페라떼 : %d원\n", latte * 3000);
		System.out.printf("베이글 : %d원\n", bagel * 1500);
		System.out.printf("크림치즈 : %d원\n", cream * 500);

		// 총액
		System.out.println("======================");

		float sum = ame * 2000 + latte * 3000 + bagel * 1500 + cream * 500;
		System.out.printf("총액 : %.0f원\n", sum);

		if (sum >= 12000 && sum < 30000) {
			System.out.printf("포인트 적립 : %.0f원", sum * 0.01);
		} else if (sum >= 30000) {
			System.out.printf("포인트 적립 : %.0f원", sum * 0.02);
		}

	}

}
