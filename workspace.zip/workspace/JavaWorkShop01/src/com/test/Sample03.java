package com.test;

public class Sample03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		var a = 100;
		System.out.println(a);
		var b = "송민기";
		System.out.println(b);
		final double PI = 3.141592;
		System.out.println(PI);
	}

}
