package com.test;

import java.util.Scanner;

public class Sample10 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("#####메뉴#####");
		System.out.println("#  1.탕수육  #");
		System.out.println("#  2.불짬뽕  #");
		System.out.println("#  3.간짜장  #");
		System.out.print("메뉴 번호를 입력해주세요 : ");
		int sel = in.nextInt();
		if (sel == 1) {
			System.out.println("탕수육을 선택하셨습니다.");
		} else if (sel == 2) {
			System.out.println("짬뽕을 선택하셨습니다.");
		} else if (sel == 3) {
			System.out.println("간짜장을 선택하셨습니다.");
		} else {
			System.out.println("잘가~");
		}

	}

}
