package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyFirstServlet implements Servlet {
	@Override
	public void destroy() {
		System.out.println("Service Destoryed");
	}
	@Override
	public ServletConfig getServletConfig() {
		return this.config;
	}
	@Override
	public String getServletInfo() {		
		return "My First Sevlet Version 1.0";
	}

	ServletConfig config = null;
	@Override
	public void init(ServletConfig config) throws ServletException {
		this.config = config;	
		System.out.println("Servlet Initialized");
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.print("<html><body>");
		out.print("<b>Hello My First Servlet</b>");
		out.print("</body></html>");		
	}
}
